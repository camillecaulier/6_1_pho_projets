#!/bin/bash

NPROC=8
RUN=5

rm -f philosophers.CSV
rm -f philosophers_bis.CSV
echo "thread","time" >> philosophers.CSV
echo "thread","time" >> philosophers_bis.CSV
make philo
make philob
for((i=1;i<=RUN;i++))
do
    for((n=1;n<=NPROC;n++))
    do
    echo $n
        OUTPUT=$((/usr/bin/time -f %e ./philo $n 2>&1) | cut -d\) -f2)
        echo $n, $OUTPUT >> philosophers.CSV
        OUTPUT2=$((/usr/bin/time -f %e ./philob $n 2>&1) | cut -d\) -f2)
        echo $n, $OUTPUT2 >> philosophers_bis.CSV
    done
done
make clean -s 2> /dev/null