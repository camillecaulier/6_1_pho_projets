#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

typedef struct mutex_t{
    int lockval;
}mutex_t;

void lock(mutex_t* mutex){
    __asm__("test:;");
    while (mutex->lockval==1){}    
    __asm__(
        "xchgl %%eax, %0;"
        "testl %%eax, %%eax;"
        "jnz test;"
        :"=m"(mutex->lockval)
        :"a"(1)
    );
}

void unlock(mutex_t* mutex){
    mutex->lockval=0;
}

void mutex_init(mutex_t* mutex, int val){
    mutex->lockval=val;
}