typedef struct sema_t{
    int size;
    int lockval_count;
    int lockval_queue;
}sema_t;

void sema_init(sema_t* sem, int size);

void wait(sema_t* sem);

void post(sema_t* sem);

