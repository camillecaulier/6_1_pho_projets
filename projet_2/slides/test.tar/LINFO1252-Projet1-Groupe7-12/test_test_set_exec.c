#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "test_test_set.h"

int N;
mutex_t foomutex;

void * foo(){
    for (int i = 0; i < 6400/N; i++)
    {
        lock(&foomutex);
        while(rand() > RAND_MAX/10000);
        unlock(&foomutex);
    }
    pthread_exit(NULL);
    
}

int main(int argc, char** argv){
    N=atoi(argv[1]);
    pthread_t threads[N];
    mutex_init(&foomutex,0);
    for (int i = 0; i < N; i++)
    {
        pthread_create(&threads[i],NULL,foo,NULL);
    }
    for (int i = 0; i < N; i++)
    {
        pthread_join(threads[i],NULL);
    }
}