#!/usr/bin/env python3

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

data = pd.read_csv("philosophers.CSV")
data_bis = pd.read_csv("philosophers_bis.CSV")

mean = data.groupby(["thread"]).mean()["time"]
std = data.groupby(["thread"]).std()["time"]
threads = data["thread"].unique()

mean_bis = data_bis.groupby(["thread"]).mean()["time"]
std_bis = data_bis.groupby(["thread"]).std()["time"]
threads_bis = data_bis["thread"].unique()

fig1 = plt.figure()

plt.plot(threads, mean, color="blue", linewidth=1.0, linestyle="-")
plt.errorbar(threads, mean, yerr=std, fmt='-o')

plt.plot(threads_bis, mean_bis, color="orange", linewidth=1.0, linestyle="-")
plt.errorbar(threads_bis, mean_bis, yerr=std, fmt='-o')

plt.xlim(0,9)
plt.ylim(0,3)

plt.xlabel('# threads')
plt.ylabel('Temps [s]')
plt.title("Temps moyen de l'exécution du problème des philosophes")
plt.grid(True)
plt.legend(['Native mutex & semaphore','Active mutex & semaphores'], loc = 'upper right')

plt.savefig("philosophers.png")


#plt.show()
plt.close()
