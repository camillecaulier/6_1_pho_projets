# LINFO1252-Projet1-Groupe7-12
If you want to test, compare the __performance__ of the program with a different number of __threads__ or __tests__ and display the results on a graph, follow these instructions carefully : 

* First you need to install __python3__ by taping these two commands : 

```console
-> sudo apt-get update
-> sudo apt-get install python3
```

* Then you have to install the __pandas__ and __matplotlib__ packages by executing these commands :

```console
-> sudo apt-get install python3-pip
-> sudo apt-get install python3-pandas
-> pip3 install matplotlib
```

* To display __graphs__ in order to run the program, you need to install a __display server__ beforehand by uploading and downloading __Xming__ via this website : 

https://sourceforge.net/projects/xming/

* Once installed, you still have to configure it by taping :

```console
-> sudo apt-get install python3.7-tk (peut changer selon votre version de python3)
-> export DISPLAY=localhost:0.0
-> sudo apt-get install python3-gi-cairo
```