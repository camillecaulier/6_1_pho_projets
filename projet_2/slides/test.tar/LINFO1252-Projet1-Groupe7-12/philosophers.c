#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <semaphore.h>


#define LEFT (philo -1 + N)%N
#define RIGHT (philo +1 )%N


unsigned int N;  //nombre de philosophes


typedef enum {PENSE, MANGE, FAIM} etat;

etat *et;         // etats des philosophes
sem_t *philos;     //une sem par philosophe
sem_t mutex;      //protège la variable partagée "et"

void test(int i){
    if(et[i] == FAIM && et[(i-1+N)%N] != MANGE && et[(i+1)%N] != MANGE){
        et[i] = MANGE;
        sem_post(&philos[i]);
    }
}
void eat(int i){
    sem_wait(&mutex);
    et[i] = FAIM;
    test(i);
    sem_post(&mutex);
    sem_post(&philos[i]);
}
void rest(int i){
    sem_wait(&mutex);
    et[i] = PENSE;
    test((i-1+N)%N);
    test((i+1)%N);
    sem_post(&mutex);
}

void * philosophe(void * arg){
    int philo = *(int *) arg;
    int p = 0;
    while(p<100000){
        eat(philo);
        rest(philo);
        p++;

    }
    pthread_exit(NULL);
}

int main(int argc, char ** argv){
    N = atoi(argv[1]);
    if(N <= 0){
        printf("Il n'y a aucun philosophe \n");
        pthread_exit("");
    }
    pthread_t thread[N];
    
    et = (etat *) malloc(sizeof(etat)*N);
    philos = (sem_t *) malloc(sizeof(sem_t)*N);
    sem_init(&mutex, 0,1);
    int * j = (int *) malloc(sizeof(int)*N); //Arguments pour les threads, pouvoir caster en (void *)
    /* Initialisaiton des sémaphores et tableaux*/
    for (int i = 0; i<N; i++){
        sem_init(&philos[i], 0,0);
        et[i] = PENSE;
        j[i] = i;
    }
    /* Creation des threads */
    for(int i = 0; i<N; i++){
        pthread_create(&thread[i], NULL, philosophe, (void *) (&j[i]));
    }
    for(int i = 0; i<N; i++){
        pthread_join(thread[i], NULL);
    }
    for(int i = 0; i<N; i++){
        sem_destroy(&philos[i]);
    }
    sem_destroy(&mutex);
    free(et);
    free(j);
    free(philos);
    pthread_exit("");

}
