#!/bin/bash

NPROC=8
RUN=5

rm -f producers_consumers.CSV
rm -f producers_consumers_bis.CSV
echo "thread","time" >> producers_consumers.CSV
echo "thread","time" >> producers_consumers_bis.CSV
make PC
make PCb
for((i=1;i<=RUN;i++))
do
    for((n=1;n<=NPROC;n++))
    do
    echo $n
        OUTPUT=$((/usr/bin/time -f %e ./PC $n 2>&1) | cut -d\) -f2)
        echo $n, $OUTPUT >> producers_consumers.CSV
        OUTPUT2=$((/usr/bin/time -f %e ./PCb $n 2>&1) | cut -d\) -f2)
        echo $n, $OUTPUT2 >> producers_consumers_bis.CSV
    done
done
make clean -s 2> /dev/null