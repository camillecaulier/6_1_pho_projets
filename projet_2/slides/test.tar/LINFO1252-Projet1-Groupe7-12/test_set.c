#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

typedef struct mutexb_t{
    int lockval;
}mutexb_t;

void lockb(mutexb_t* mutex){
    __asm__ (
    "test:;"
    "xchgl %%eax, %0;"
    "testl %%eax, %%eax;"
    "jnz test;"
    :"=m"(mutex->lockval)
    :"a"(1)
    );
}

void unlockb(mutexb_t* mutex){
    mutex->lockval=0;
}

void mutex_initb(mutexb_t* mutex, int val){
    mutex->lockval=val;
}