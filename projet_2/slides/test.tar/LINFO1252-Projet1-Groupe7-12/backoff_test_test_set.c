#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define MIN 10
#define MAX 10000

typedef struct mutexc_t{
    int lockval;
}mutexc_t;

int N;
mutexc_t foomutex;

void lockc(mutexc_t* mutex){
    __asm__("test:;");
    struct timespec tim;
    unsigned int time_sleep = MIN;
    while (mutex->lockval==1){
        tim.tv_nsec = (time_sleep-rand()%(time_sleep/2))*1000; 
        nanosleep(&tim,NULL); 
        if(2*time_sleep <= MAX) 
            time_sleep *=2;
        else
            time_sleep = MAX;
    }    
    __asm__(
        "xchgl %%eax, %0;"
        "testl %%eax, %%eax;"
        "jnz test;"
        :"=m"(mutex->lockval)
        :"a"(1)
    );
}

void unlockc(mutexc_t* mutex){
    mutex->lockval=-1;
}

void mutexc_init(mutexc_t* mutex, int val){
    mutex->lockval=val;
}

void * foo(){
    for (int i = 0; i < 6400/N; i++)
    {
        lockc(&foomutex);
        while(rand() > RAND_MAX/10000);
        unlockc(&foomutex);
    }
    pthread_exit(NULL);
    
}

int main(int argc, char** argv){
    N=atoi(argv[1]);
    pthread_t threads[N];
    mutexc_init(&foomutex,0);
    for (int i = 0; i < N; i++)
    {
        pthread_create(&threads[i],NULL,foo,NULL);
    }
    for (int i = 0; i < N; i++)
    {
        pthread_join(threads[i],NULL);
    }
}