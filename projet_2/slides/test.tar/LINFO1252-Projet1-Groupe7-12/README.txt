# LINFO1252-Projet1-Groupe7-12
If you want to test, compare the __performance__ of the program with a different number of __threads__ or __tests__ and display the results on a graph, follow these instructions carefully : 

* First you need to install __python3__ by taping these two commands : 

```console
-> sudo apt-get update
-> sudo apt-get install python3
```

* Then you have to install the __pandas__ and __matplotlib__ packages by executing these commands :

```console
-> sudo apt-get install python3-pip
-> sudo apt-get install python3-pandas
-> pip3 install matplotlib
```
# Content :
    
    - Makefile : consign for all the 'make' commands. Allows us to generate executables and tests.
    - philosophers.c : The main program to solve the "dinning philosophe problem", using POSIX librairy.
    - philosophers.sh : Bash scirpt who compute the averga time of execution of the two implementations with differents numbers of threads.
    - philosophers.py : Generate graphs to compare our implementations. 
    - philosophers_bis.c : The main program to solve the "dinning philosophe problem", using our active mutex and semaphores.
    - producers_consumers.c : The main program to solve the "producer-consumer" problem, using POSIX librairy.
    - producers_consumers.sh : Bash scirpt who compute the averga time of execution of the two implementations with differents numbers of threads.
    - producers_consumers.py : Generate graphs to compare our implementations. 
    - producers_consumers_bis.c : The main program to solve the "producers_consumers" problem, using our active mutex and semaphores.
    - readers_writers.c : The main program to solve the "reader-writer" problem, using the POSIX librairy.
    - readers_writers.sh : Bash scirpt who compute the averga time of execution of the two implementations with differents numbers of threads.
    - readers_writers.py : Generate graphs to compare our implementations. 
    - readers_writers_bis.c : The main program to solve the "readers_writers" problem, using our active mutex and semaphores.
    - semaphores.c : Implementation of our semaphores with our actives locks.
    - semaphores.h : Header of semaphore.c.
    - test_set.c : Basic implémentation of our locks.
    - test_set.h : Header of test_set.c.
    - test_test_set.c : Advanced implementation of our locks.
    - test_test_set.h : Header of test_test_set.c.
    - TsvsTTS.sh : Bash scirpt who compute the averga time of execution of the two implementations with differents numbers of threads.
    - TsvsTTS.py : Generate graphs to compare our implementations. 

# Instructions :

    - To get every executables : use 'make' command
    - You can now run any program, bu using its identifiant and by giving it a number of threads. The differents identifiants to use are : philo (philosophers)
    , philob (philosophers_bis), PC (producers_consumers), PCb (producers_consumers_bis), RW (readers_writers), RWb (readers_writers_bis), TS (test_set),
     TTS (test_test_set). You can now use them as following : ./identifiant N where N is the number of threads with wich you wanna run the program. N has to be 
     stricly positive. 
    - You also may be able to run differents tests. You can enter make valgrind, to run a memory error detector on every program. You can run "make test" to 
    run every script bash. It also gonna run the python script and produce the png graphics.
    - When you are finished, you can run 'make clean' to clean the repertory.
