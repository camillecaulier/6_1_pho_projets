typedef struct mutexc_t{
    int lockval;
}mutexc_t;

void lockc(mutexc_t* mutex);

void unlockc(mutexc_t* mutex);

void mutexc_init(mutexc_t* mutex, int val);