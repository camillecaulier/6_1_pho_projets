#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "semaphores.h"
#include "test_test_set.h"

#define SIZE 1024     /* Nombre d'éléments a traiter */
#define BUFFERSIZE 8  /* Taille du buffer */
unsigned int N, P, C;
int buffer[BUFFERSIZE];
int produceCount = 0;
int consumeCount = 0;

mutex_t buff;   
mutex_t countProduce;   //Protège la variable produceCount

sema_t empty;
sema_t full;
int current = BUFFERSIZE;

void * produce(){
    while (1)
    {
        lock(&countProduce);
        if (produceCount>=1024){
            unlock(&countProduce);
            break;
        }
        produceCount++;
        //printf("produceCount=%d\n",produceCount);
        unlock(&countProduce);

        wait(&empty);
        lock(&buff);
        buffer[current-1]=rand();
        current--;
        unlock(&buff);
        post(&full);
        while(rand() > RAND_MAX/10000);
    }
    post(&full);
    //printf("here\n");
    pthread_exit(NULL);    
}

void * consume(){
    while (1){
        wait(&full);
        lock(&buff);
        if (produceCount>=1024 && current==BUFFERSIZE){
            post(&full);
            unlock(&buff);
            break;
        }
        int item = buffer[current];
        item++;
        current++;
        consumeCount++;
        //printf("consumed=%d\n",consumeCount);
        unlock(&buff);
        post(&empty);
        while(rand() > RAND_MAX/10000);
    }
    pthread_exit(NULL);
    //printf("there\n");
}

int main(int argc, char** argv){
    N = atoi(argv[1]);
    if (N<=2){
        P = 1;
        C = 1;
    }
    else if (N%2!=0){
        P = (N-1)/2;
        C = P+1;
    }else{
        P = N/2;
        C = N/2;
    }
    
    pthread_t producers[P];
    pthread_t consumers[C];
    //ARG 3 et 4 sont INT_MIN et INT_MAX ?
    srand(time(NULL));


    //initialize all mutex
    mutex_init(&buff, 0);
    mutex_init(&countProduce, 0);

    //initialize all semaphore
    sema_init(&empty, BUFFERSIZE);
    sema_init(&full,0);

	//create and run threads
	for (int i=0; i<P; i++) {
		pthread_create(&producers[i],NULL,produce,NULL);
	}
	for (int i=0; i<C; i++) {
		pthread_create(&consumers[i],NULL,consume,NULL);
	}

    //waiting for threads to end
	for (int i=0; i<P; i++){
        pthread_join(producers[i],NULL);
    }
    for (int i=0; i<C; i++){
        pthread_join(consumers[i],NULL);
    }
	 
	pthread_exit(NULL);

}
