typedef struct mutex_t{
    int lockval;
}mutex_t;

void lock(mutex_t* mutex);

void unlock(mutex_t* mutex);

void mutex_init(mutex_t* mutex, int val);

