#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "test_test_set.h"

typedef struct sema_t{
    int size;
    mutex_t count;
    mutex_t queue;
}sema_t;



void sema_init(sema_t* sem, int size){
    sem->size=size;
    mutex_init(&(sem->count),0);
    mutex_init(&(sem->queue),1);
}

void wait(sema_t* sem){
    lock(&(sem->count));
    sem->size--;
    if (sem->size<0){
        sem->queue.lockval=1;
        unlock(&(sem->count));
        lock(&(sem->queue));
    }
    unlock(&(sem->count));
}

void post(sema_t* sem){
    lock(&(sem->count));
    sem->size++;
    if (sem->size<=0){
        unlock(&(sem->queue));
    }else{
        unlock(&(sem->count));
    }
}