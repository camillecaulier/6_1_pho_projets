#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "test_set.h"

int N;
mutexb_t foomutex;

void * foo(){  
    for (int i = 0; i < 6400/N; i++)
    {
        lockb(&foomutex);
        while(rand() > RAND_MAX/10000);
        unlockb(&foomutex);
    }
    pthread_exit(NULL);
    
}

int main(int argc, char** argv){
    N=atoi(argv[1]);
    pthread_t threads[N];
    mutex_initb(&foomutex,0);
    for (int i = 0; i < N; i++)
    {
        pthread_create(&threads[i],NULL,foo,NULL);
    }
    for (int i = 0; i < N; i++)
    {
        pthread_join(threads[i],NULL);
    }
}