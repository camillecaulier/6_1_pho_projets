#!/bin/bash

NPROC=8
RUN=5

rm -f readers_writers.CSV
rm -f readers_writers_bis.CSV
echo "thread","time" >> readers_writers.CSV
echo "thread","time" >> readers_writers_bis.CSV
make RW
make RWb
for((i=1;i<=RUN;i++))
do
    for((n=1;n<=NPROC;n++))
    do
    echo $n
        OUTPUT=$((/usr/bin/time -f %e ./RW $n 2>&1) | cut -d\) -f2)
        echo $n, $OUTPUT >> readers_writers.CSV
        OUTPUTB=$((/usr/bin/time -f %e ./RWb $n 2>&1) | cut -d\) -f2)
        echo $n, $OUTPUTB >> readers_writers_bis.CSV
    done
done
make clean -s 2> /dev/null