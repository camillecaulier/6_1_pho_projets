#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <string.h>
#include "semaphores.h"
#include "test_test_set.h"

unsigned int N, W, R;
mutex_t writerMutex;
mutex_t readerMutex;
int writecount=0;
int readcount=0;
sema_t writeSem;
sema_t readSem;

int totalWrite=0;
int totalRead=0;
mutex_t countWrite;
mutex_t countRead;

void *writer() {
    while(1){
        lock(&countWrite);
        if (totalWrite>=640){
            unlock(&countWrite);
            break;
        }
        totalWrite++;
        unlock(&countWrite);
        
        lock(&writerMutex);
        writecount+=1;
        if(writecount==1){
            wait(&readSem);
        }
        unlock(&writerMutex);
        wait(&writeSem);

        //execute_section_critique
        while(rand() > RAND_MAX/10000);
        //printf("written\n");

        post(&writeSem);
        lock(&writerMutex);
        writecount-=1;
        if(writecount==0){
            post(&readSem);
        }
        unlock(&writerMutex);
    }  
    pthread_exit(NULL);
}

void *reader() {
    while(1){
        lock(&countRead);
        if (totalRead>=2560){
            unlock(&countRead);
            break;
        }
        totalRead++;
        unlock(&countRead);

        wait(&readSem);
        lock(&readerMutex);
        readcount+=1;
        if(readcount==1){
            wait(&writeSem);
        }
        unlock(&readerMutex);
        post(&readSem);

        //execute_section_critique
        while(rand() > RAND_MAX/10000);
        //printf("read\n");

        lock(&readerMutex);
        readcount-=1;
        if(readcount==0){
            post(&writeSem);
        }
        unlock(&readerMutex);
    }
    pthread_exit(NULL);
}

int main(int argc, char **argv) {
	N = atoi(argv[1]);
    if (N%2!=0){
        W = (N-1)/2;
        R = W+1;
    }else{
        W = N/2;
        R = N/2;
    }
    pthread_t writers[W];
    pthread_t readers[R];
    
	
	//initialize all mutex
    mutex_init(&writerMutex,0);
    mutex_init(&readerMutex,0);
    mutex_init(&countWrite,0);
    mutex_init(&countRead,0);

    //initialize all semaphore
    sema_init(&writeSem, 1);
    sema_init(&readSem, 1);

	//create and run threads
	for (int i=0; i<W; i++) {
		pthread_create(&writers[i],NULL,writer,NULL);
	}
	for (int i=0; i<R; i++) {
		pthread_create(&readers[i],NULL,reader,NULL);
	}

    //waiting for threads to end
	for (int i=0; i<W; i++){
        pthread_join(writers[i],NULL);
    }
    for (int i=0; i<R; i++){
        pthread_join(readers[i],NULL);
    }
	 
	pthread_exit(NULL);
}