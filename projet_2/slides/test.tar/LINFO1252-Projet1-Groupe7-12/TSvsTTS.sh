#!/bin/bash

NPROC=8
RUN=5

rm -f test_set.CSV
rm -f test_test_set.CSV
echo "thread","time" >> test_set.CSV
echo "thread","time" >> test_test_set.CSV
make TS
make TTS
for((i=1;i<=RUN;i++))
do
    for((n=1;n<=NPROC;n++))
    do
    echo $n
        OUTPUT=$((/usr/bin/time -f %e ./TS $n 2>&1) | cut -d\) -f2)
        echo $n, $OUTPUT >> test_set.CSV
        OUTPUTB=$((/usr/bin/time -f %e ./TTS $n 2>&1) | cut -d\) -f2)
        echo $n, $OUTPUTB >> test_test_set.CSV
    done
done
make clean -s 2> /dev/null