#!/usr/bin/env python3

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

data = pd.read_csv("producers_consumers.CSV")
data_bis = pd.read_csv("producers_consumers_bis.CSV")

mean = data.groupby(["thread"]).mean()["time"]
std = data.groupby(["thread"]).std()["time"]
threads = data["thread"].unique()

mean_bis = data_bis.groupby(["thread"]).mean()["time"]
std_bis = data_bis.groupby(["thread"]).std()["time"]
threads_bis = data_bis["thread"].unique()

fig1 = plt.figure()

plt.plot(threads, mean, color="blue", linewidth=1.0, linestyle="-")
plt.errorbar(threads, mean, yerr=std, fmt='-o')

plt.plot(threads_bis, mean_bis, color="orange", linewidth=1.0, linestyle="-")
plt.errorbar(threads_bis, mean_bis, yerr=std, fmt='-o')

plt.xlim(0,9)
plt.ylim(0,6)

plt.xlabel('# threads')
plt.ylabel('Temps [s]')
plt.title("Temps moyen de l'exécution du problème des consommateurs et producteurs")
plt.grid(True)
plt.legend(['Native mutex and semaphore','Active mutex and semaphore'], loc = 'upper right')

plt.savefig("producers_consumers.png")


#plt.show()
plt.close()
