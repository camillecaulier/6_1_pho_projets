#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <string.h>
#include <semaphore.h>

unsigned int N, W, R;
pthread_mutex_t writerMutex;
pthread_mutex_t readerMutex;
int writecount=0;
int readcount=0;
sem_t writeSem;
sem_t readSem;

int totalWrite=0;
int totalRead=0;
pthread_mutex_t countWrite;
pthread_mutex_t countRead;

void *writer() {
    while(1){
        pthread_mutex_lock(&countWrite);
        if (totalWrite>=640){
            pthread_mutex_unlock(&countWrite);
            break;
        }
        totalWrite++;
        pthread_mutex_unlock(&countWrite);
        
        pthread_mutex_lock(&writerMutex);
        writecount+=1;
        if(writecount==1){
            sem_wait(&readSem);
        }
        pthread_mutex_unlock(&writerMutex);
        sem_wait(&writeSem);

        //execute_section_critique
        while(rand() > RAND_MAX/10000);
        //printf("written\n");

        sem_post(&writeSem);
        pthread_mutex_lock(&writerMutex);
        writecount-=1;
        if(writecount==0){
            sem_post(&readSem);
        }
        pthread_mutex_unlock(&writerMutex);
    }  
    pthread_exit(NULL);
}

void *reader() {
    while(1){
        pthread_mutex_lock(&countRead);
        if (totalRead>=2560){
            pthread_mutex_unlock(&countRead);
            break;
        }
        totalRead++;
        pthread_mutex_unlock(&countRead);

        sem_wait(&readSem);
        pthread_mutex_lock(&readerMutex);
        readcount+=1;
        if(readcount==1){
            sem_wait(&writeSem);
        }
        pthread_mutex_unlock(&readerMutex);
        sem_post(&readSem);

        //execute_section_critique
        while(rand() > RAND_MAX/10000);
        //printf("read\n");

        pthread_mutex_lock(&readerMutex);
        readcount-=1;
        if(readcount==0){
            sem_post(&writeSem);
        }
        pthread_mutex_unlock(&readerMutex);
    }
    pthread_exit(NULL);
}

int main(int argc, char **argv) {
	N = atoi(argv[1]);
    if (N==1 || N==2){
        W = 1;
        R = 1;
    }
    
    else if (N%2!=0){
        W = (N-1)/2;
        R = W+1;
    }else{
        W = N/2;
        R = N/2;
    }
    pthread_t writers[W];
    pthread_t readers[R];
    
	
	//initialize all mutex
    pthread_mutex_init(&writerMutex,NULL);
    pthread_mutex_init(&readerMutex,NULL);
    pthread_mutex_init(&countWrite,NULL);
    pthread_mutex_init(&countRead,NULL);

    //initialize all semaphore
    sem_init(&writeSem, 0, 1);
    sem_init(&readSem, 0, 1);

	//create and run threads
	for (int i=0; i<W; i++) {
		pthread_create(&writers[i],NULL,writer,NULL);
	}
	for (int i=0; i<R; i++) {
		pthread_create(&readers[i],NULL,reader,NULL);
	}

    //waiting for threads to end
	for (int i=0; i<W; i++){
        pthread_join(writers[i],NULL);
    }
    for (int i=0; i<R; i++){
        pthread_join(readers[i],NULL);
    }
		
	
	//destroy variables and free up memory
	pthread_mutex_destroy(&writerMutex);
	pthread_mutex_destroy(&readerMutex);
    pthread_mutex_destroy(&countWrite);
    pthread_mutex_destroy(&countRead);
    sem_destroy(&writeSem);
    sem_destroy(&readSem);
	 
	pthread_exit(NULL);
}