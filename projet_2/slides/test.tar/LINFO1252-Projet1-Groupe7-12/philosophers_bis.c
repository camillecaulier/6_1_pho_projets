#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "semaphores.h"
#include "test_test_set.h"


unsigned int N;  //nombre de philosophes


typedef enum {PENSE, MANGE, FAIM} etat;

etat *et;         // etats des philosophes
sema_t *philos;     //une sem par philosophe
sema_t mutex;      //protège la variable partagée "et"

void test(int i){
    if(et[i] == FAIM && et[(i-1+N)%N] != MANGE && et[(i+1)%N] != MANGE){
        et[i] = MANGE;
        post(&philos[i]);
    }
}
void eat(int i){
    wait(&mutex);
    et[i] = FAIM;
    test(i);
    post(&mutex);
    post(&philos[i]);
}
void rest(int i){
    wait(&mutex);
    et[i] = PENSE;
    test((i-1+N)%N);
    test((i+1)%N);
    post(&mutex);
}

void * philosophe(void * arg){
    int philo = *(int *) arg;
    int p = 0;
    while(p<100000){
        eat(philo);
        rest(philo);
        p++;

    }
    pthread_exit(NULL);
}

int main(int argc, char ** argv){
    N = atoi(argv[1]);
    if(N <= 0){
        printf("Il n'y a aucun philosophe \n");
        pthread_exit("");
    }
    pthread_t thread[N];

    /* Allocation des tableaux */
    et = (etat *) malloc(sizeof(etat)*N);
    philos = (sema_t *) malloc(sizeof(sema_t)*N);
    int * j = (int *) malloc(sizeof(int)*N);                //Arguments pour les threads, pouvoir caster en (void *)

    /* Initialisaiton des sémaphores et tableaux*/
    for (int i = 0; i<N; i++){
        sema_init(&philos[i],0);
        et[i] = PENSE;
        j[i] = i;
    }
    sema_init(&mutex,1);

    /* Creation des threads */
    for(int i = 0; i<N; i++){
        pthread_create(&thread[i], NULL, philosophe, (void *) (&j[i]));
    }
    for(int i = 0; i<N; i++){
        pthread_join(thread[i], NULL);
    }
    
    /* Libération de la mémoire allouée */
    free(et);
    free(j);
    free(philos);
    pthread_exit("");

}
