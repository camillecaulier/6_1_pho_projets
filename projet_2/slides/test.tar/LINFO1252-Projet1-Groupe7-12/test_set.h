typedef struct mutexb_t{
    int lockval;
}mutexb_t;

void lockb(mutexb_t* mutex);

void unlockb(mutexb_t* mutex);

void mutex_initb(mutexb_t* mutex, int val);